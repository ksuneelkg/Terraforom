#!/bin/bash
sudo yum update -y
sudo yum install -y httpd24 php56 php56-mysqlnd
#sudo yum install httpd -y
cat <<EOF > /var/www/html/index.html
<ht> Hello World</h1>
<p>DB Address: ${rds_db_address}</p>
<p>DB Port: ${rds_db_port}</p>
EOF
sudo service httpd restart
sudo chkconfig httpd on
sudo groupadd www
sudo usermod -a -G www ec2-user
sudo chown -R root:www /var/www
sudo chmod 2775 /var/www
find /var/www -type d -exec sudo chmod 2775 {} +
find /var/www -type f -exec sudo chmod 0664 {} +
cd /var/www
mkdir inc
cd inc
cat <<EOF >/var/www/inc/dbinfo.inc
<?php

define('DB_SERVER', '${rds_db_address}');
define('DB_USERNAME', '${rds_db_user}');
define('DB_PASSWORD', '${rds_db_password}');
define('DB_DATABASE', '${rds_db_name}');

?>
EOF
cat << 'EOF' >/var/www/html/SamplePage.php
${php_file}
EOF

sudo service httpd restart